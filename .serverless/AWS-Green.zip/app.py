from flask import Flask, jsonify, make_response, render_template
import os

app = Flask(__name__,
            static_url_path='',
            template_folder=os.path.abspath('core/templates'),
            static_folder='core/static'
            )


@app.route("/")
def hello_from_root():
    test = "<h1>Hello from the other side</h1>/n<h4>away we go!</h4>"
    return jsonify(message=test)


@app.route("/1", methods=['GET'])
def regular_template():
    return render_template('index.html')


@app.errorhandler(404)
def resource_not_found(e):
    return make_response(jsonify(error='Not found!'), 404)
